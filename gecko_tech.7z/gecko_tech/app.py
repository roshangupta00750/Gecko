from flask import Flask, request, send_from_directory, jsonify
from flask_socketio import SocketIO
import threading, time
import RPi.GPIO as GPIO
import serial
import struct
from datetime import datetime

# === Global State ===
stop_threads = False
latest_force = {"Fx": 0.0, "Fy": 0.0, "Fz": 0.0}
sequence_running = False
serial_lock = threading.Lock()
MAX_FORCE_SENSOR_LIMIT = 10 #10 Newtons
motor_check_status = {"X": False, "Y": False, "Z": False}

# --- Continuous jog state ---
jog_flags = {"X": False, "Y": False, "Z": False}
jog_threads = {"X": None, "Y": None, "Z": None}

# === Flask & SocketIO Setup ===
app = Flask(__name__, static_folder='static')
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# === GPIO Setup ===
GPIO.setmode(GPIO.BCM)
AXES = {
    "X": (24, 25),
    "Y": (16, 26),
    "Z": (27, 17),
}
for step_pin, dir_pin in AXES.values():
    GPIO.setup(step_pin, GPIO.OUT, initial=GPIO.LOW)
    GPIO.setup(dir_pin, GPIO.OUT, initial=GPIO.LOW)

# --- Safe GPIO output ---
def safe_gpio_output(pin, value):
    try:
        GPIO.output(pin, value)
    except RuntimeError as e:
        print(f"GPIO output error on pin {pin}: {e}")

# === Serial Sensor Setup ===
SERIAL_PORT = '/dev/ttyUSB0'
BAUDRATE = 115200
CALIBRATION_FACTORS = {'Fx': 10.0 / 0.5, 'Fy': 10.0 / 0.5, 'Fz': 10.0 / 0.5}

ser = serial.Serial(SERIAL_PORT, BAUDRATE, timeout=1)
with serial_lock:
    ser.write(b'\x23')
    time.sleep(0.1)
    ser.write(b'\x26\x01\x62\x65\x72\x6C\x69\x6E')
    time.sleep(0.1)
    ser.write(b'\x12\xA6')  # 12.5 Hz
    time.sleep(0.1)
    ser.write(b'\x24')
print("Serial sensor initialized")

# === Read Force Function ===
def read_force():
    with serial_lock:
        frame = ser.read(11)
    if len(frame) != 11 or frame[0] != 0xA5:
        return None
    fx = struct.unpack('>H', frame[1:3])[0]
    fy = struct.unpack('>H', frame[3:5])[0]
    fz = struct.unpack('>H', frame[5:7])[0]
    def raw_to_mv_v(raw): return (raw - 32768) / 32768 * 2.0
    return {
        'Fx': round(raw_to_mv_v(fx) * CALIBRATION_FACTORS['Fx'], 2),
        'Fy': round(raw_to_mv_v(fy) * CALIBRATION_FACTORS['Fy'], 2),
        'Fz': round(raw_to_mv_v(fz) * CALIBRATION_FACTORS['Fz'], 2)
    }

# === Force Poller Thread ===
def force_poller():
    print("Starting force poller...")
    while not stop_threads:
        data = read_force()
        if data:
            latest_force.update(data)
            socketio.emit("force", latest_force)
            print(f"[emit] force {latest_force}")
        time.sleep(0.05)

# === Motor Check Function ===
def motor_check():
    global motor_check_status
    motor_check_status = {"X": False, "Y": False, "Z": False}
    socketio.emit("log", "Starting motor check sequence...")

    def move_axis_forward_backward(axis):
        step_pin, dir_pin = AXES[axis]
        steps_fwd = 0
        steps_bwd = 0

        safe_gpio_output(dir_pin, GPIO.HIGH)  # Forward direction
        start_time = time.time()
        while time.time() - start_time < 2.0:
            safe_gpio_output(step_pin, GPIO.HIGH)
            time.sleep(0.01)
            safe_gpio_output(step_pin, GPIO.LOW)
            time.sleep(0.01)
            steps_fwd += 1

        safe_gpio_output(dir_pin, GPIO.LOW)  # Reverse direction
        start_time = time.time()
        while time.time() - start_time < 2.0:
            safe_gpio_output(step_pin, GPIO.HIGH)
            time.sleep(0.01)
            safe_gpio_output(step_pin, GPIO.LOW)
            time.sleep(0.01)
            steps_bwd += 1

        motor_check_status[axis] = (steps_fwd > 0 and steps_bwd > 0)
        socketio.emit(
            "log",
            f"{axis} motor test {'Motor validation successful' if motor_check_status[axis] else 'Motor validation failed'} "
            f"(forward steps: {steps_fwd}, backward steps: {steps_bwd})"
        )

    threads = []
    for axis in ["X", "Y", "Z"]:
        t = threading.Thread(target=move_axis_forward_backward, args=(axis,))
        t.start()
        threads.append(t)

    for t in threads:
        t.join()

    socketio.emit("motor_check_status", motor_check_status)
    socketio.emit("log", "Motor check sequence complete")

# === Continuous Jog (Hold-to-Move) ===
def jog_continuous(axis, direction, step_delay=0.01):
    step_pin, dir_pin = AXES[axis]
    safe_gpio_output(dir_pin, GPIO.HIGH if direction else GPIO.LOW)
    while jog_flags[axis]:
        safe_gpio_output(step_pin, GPIO.HIGH)
        time.sleep(step_delay)
        safe_gpio_output(step_pin, GPIO.LOW)
        time.sleep(step_delay)

@socketio.on("manual_move_start")
def handle_manual_move_start(data):
    axis = data.get("axis")
    direction = data.get("direction")
    if axis not in AXES:
        socketio.emit("log", f"Invalid axis: {axis}")
        return
    jog_flags[axis] = True
    if jog_threads[axis] and jog_threads[axis].is_alive():
        return
    t = threading.Thread(target=jog_continuous, args=(axis, direction))
    t.daemon = True
    jog_threads[axis] = t
    t.start()
    socketio.emit("log", f"▶️ Started jogging {axis} ({'+' if direction else '-'})")

@socketio.on("manual_move_stop")
def handle_manual_move_stop(data):
    axis = data.get("axis")
    if axis in jog_flags:
        jog_flags[axis] = False
        socketio.emit("log", f"⏹️ Stopped jogging {axis}")

# === Improved Trigger Checking ===
def check_if_trigger_fired(trigger, duration):
    try:
        if '(N)' in trigger['triggerType']:
            force_trigger_type = trigger['triggerType'].split(' (N)')[0]
            trigger_value = float(trigger['value'])
            sensor_value = float(latest_force.get(force_trigger_type))
            operator = trigger.get('operator', '>')
            if operator == '>' and sensor_value > trigger_value:
                return True
            elif operator == '>=' and sensor_value >= trigger_value:
                return True
            elif operator == '<' and sensor_value < trigger_value:
                return True
            elif operator == '<=' and sensor_value <= trigger_value:
                return True
            if sensor_value >= MAX_FORCE_SENSOR_LIMIT:
                return True
        elif 'duration' in trigger['triggerType']:
            if float(trigger['value']) >= float(duration):
                return True
    except Exception as e:
        print(f"Trigger evaluation error: {e}")
    return False


# === Movement/Step Functions ===
def move_axis(step_pin, dir_pin, direction, step_size):
    # For Z axis: positive = DOWN, negative = UP (adjust comment if your system is different)
    GPIO.output(dir_pin, GPIO.HIGH if direction == 'positive' else GPIO.LOW)
    GPIO.output(step_pin, GPIO.HIGH)
    time.sleep(step_size / 1000.0)
    GPIO.output(step_pin, GPIO.LOW)
    time.sleep(1 / 1000.0)
    print(f"[move_axis] Step: {'+' if direction == 'positive' else '-'} ({direction}) on pin {step_pin}, dir_pin {dir_pin}")



def hold_force(axis, threshold, step_pin, dir_pin):
    """
    Feedback loop to maintain force. For Z:
    - If force is too low, move DOWN (positive)
    - If force is too high, move UP (negative)
    """
    force_axis = 'F' + axis.lower()
    tolerance = 0.1  # Tighter window for less drift
    step_size = 20

    while sequence_running and not stop_threads:
        current_force = latest_force.get(force_axis)
        diff = current_force - threshold
        print(f"[hold_force] {force_axis}={current_force:.2f}, Target={threshold:.2f}, Diff={diff:.2f}")

        if abs(diff) <= tolerance:
            print("[hold_force] In tolerance window. Holding...")
            time.sleep(0.1)
        elif diff > tolerance:
            # Force too high: move UP (negative)
            print("[hold_force] Too high. Stepping negative (UP)")
            move_axis(step_pin, dir_pin, 'negative', step_size)
        elif diff < -tolerance:
            # Force too low: move DOWN (positive)
            print("[hold_force] Too low. Stepping positive (DOWN)")
            move_axis(step_pin, dir_pin, 'positive', step_size)


def hold_force_for(duration: float):
    start = time.time()
    while time.time() - start < duration and sequence_running and not stop_threads:
        time.sleep(0.1)

def move_multiple_axes(axes_dict):
    threads = []
    for axis, config in axes_dict.items():
        t = threading.Thread(
            target=move_until_force,
            args=(
                axis,
                config.get("direction") == "positive",
                config.get("triggers", []),
                1.0 / max(0.01, config.get("speed", 1.0) * 100)
            ),
            daemon=True
        )
        threads.append(t)
        t.start()
    for t in threads:
        while t.is_alive():
            if not sequence_running or stop_threads:
                return
            time.sleep(0.01)

def move_until_force(axis, direction, triggers, speed):
    step_pin, dir_pin = AXES[axis]
    force_axis = 'F' + axis.lower()
    safe_gpio_output(dir_pin, GPIO.HIGH if direction else GPIO.LOW)
    while sequence_running and not stop_threads:
        for trigger in triggers:
            if check_if_trigger_fired(trigger, 0):
                socketio.emit("log", f"Axis {axis}: {trigger['triggerType']} ≥ {trigger['value']}N, stopping")
                return
        safe_gpio_output(step_pin, GPIO.HIGH)
        time.sleep(1/speed)
        safe_gpio_output(step_pin, GPIO.LOW)
        time.sleep(1/speed)

# === Improved Step Execution with Hold Triggers ===
def execute_steps_along_axis(axis, steps):
    for s in range(len(steps)):
        step = steps[s]
        data = step['data']
        direction = data['direction']
        triggers = data['triggers']
        hold_triggers = data.get('holdTriggers', [])
        step_pin, dir_pin = AXES[axis]

        # --- FIX: Robust parsing for hold_threshold
        hold_threshold = data.get('holdThreshold')
        if hold_threshold is None or str(hold_threshold).lower() == 'nan':
            hold_threshold = None
        else:
            hold_threshold = float(hold_threshold)

        print(f"STEP {s} on axis {axis}, hold_threshold={hold_threshold}, triggers={triggers}, hold_triggers={hold_triggers}")

        # --- APPROACH PHASE (to setpoint) ---
        if hold_threshold is not None:
            while sequence_running and not stop_threads:
                current_force = latest_force.get('F' + axis.lower())
                # Check any stop triggers
                trigger_fired = False
                for trig in triggers:
                    if check_if_trigger_fired(trig, 0):
                        socketio.emit("log", f"Axis {axis}: {trig['triggerType']} {trig.get('operator','>')} {trig['value']} fired during approach.")
                        trigger_fired = True
                        break
                if trigger_fired:
                    break
                diff = current_force - hold_threshold
                if abs(diff) <= 0.1:
                    break  # reached hold point
                elif diff > 0.1:
                    move_axis(step_pin, dir_pin, 'negative', data['stepSize'])
                elif diff < -0.1:
                    move_axis(step_pin, dir_pin, 'positive', data['stepSize'])

        # --- HOLD PHASE ---
        if hold_threshold != 'NaN':
            socketio.emit("log", f"Holding force: F{axis.lower()} = {hold_threshold}N")
            while sequence_running and not stop_threads:
                # Check all hold triggers
                fired = False
                for hold_trig in hold_triggers:
                    if check_if_trigger_fired(hold_trig, 0):
                        socketio.emit("log", f"Axis {axis}: {hold_trig['triggerType']} (hold) fired.")
                        fired = True
                        break
                if fired:
                    break

                # All movement/feedback now handled INSIDE hold_force!
                hold_force(axis, hold_threshold, step_pin, dir_pin)
        else:
            # No hold: regular trigger-based move
            while sequence_running and not stop_threads:
                trigger_fired = False
                for trig in triggers:
                    if check_if_trigger_fired(trig, 0):
                        socketio.emit("log", f"Axis {axis}: {trig['triggerType']} {trig.get('operator','>')} {trig['value']} fired.")
                        trigger_fired = True
                        break
                if trigger_fired:
                    break
                move_axis(step_pin, dir_pin, direction, data['stepSize'])





# === Dynamic Sequence Execution ===
def run_dynamic_sequence(sequence):
    global sequence_running
    if sequence_running:
        return
    sequence_running = True
    socketio.emit("log", "Sequence started")
    threads = []
    for axis, steps in sequence.items():
        if not sequence_running or stop_threads:
            socketio.emit("log", "Sequence manually stopped")
            break
        if len(steps) == 0:
            continue
        t = threading.Thread(
            target=execute_steps_along_axis,
            args=(axis, steps)
        )
        t.start()
        threads.append(t)
    for t in threads:
        while t.is_alive():
            if not sequence_running or stop_threads:
                return
            time.sleep(0.1)

# === Flask Routes ===
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/live_force')
def live_force():
    return jsonify(latest_force)

@app.route('/run_sequence', methods=['POST'])
def run_sequence():
    raw = request.get_json()
    print('raw: ', raw)
    parsed = raw
    socketio.start_background_task(run_dynamic_sequence, parsed)
    return "Sequence started"

@app.route('/stop_sequence', methods=['POST'])
def stop_sequence():
    global sequence_running
    sequence_running = False
    return "Stopping"

@app.route('/motor_check')
def run_motor_check():
    socketio.start_background_task(motor_check)
    return "Motor check started"

# === App Start ===
if __name__ == '__main__':
    try:
        threading.Thread(target=force_poller, daemon=True).start()
        print("Flask-SocketIO server starting...")
        socketio.run(app, host='0.0.0.0', port=5000)
    finally:
        stop_threads = True
        time.sleep(0.2)  # Give threads time to exit
        GPIO.cleanup()
        ser.close()
        print("Clean exit")
