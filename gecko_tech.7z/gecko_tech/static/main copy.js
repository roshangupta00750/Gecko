import { createMoveStep, createHoldStep } from './stepBuilder.js';
import { renderTimeline } from './timeline.js';
import { renumberSteps, sequence, categorizeMovementSteps } from './utils.js';
import { socket } from './socket.js';

const sequenceList = document.getElementById("sequence-list");
const addActionBtnZ = document.getElementById("add-action-z");
const addActionBtnX = document.getElementById("add-action-x");
const addActionBtnY = document.getElementById("add-action-y");

const runBtn = document.getElementById("run-sequence");
const stopBtn = document.getElementById("stop-sequence");
const holdBtn = document.getElementById("add-hold");

addActionBtnZ.addEventListener("click", () => {
  const stepDiv = createMoveStep(sequence.length, renderTimeline, 'Z');
  sequenceList.appendChild(stepDiv);
  renderTimeline();
});

addActionBtnX.addEventListener("click", () => {
  const stepDiv = createMoveStep(sequence.length, renderTimeline, 'X');
  sequenceList.appendChild(stepDiv);
  renderTimeline();
});

addActionBtnY.addEventListener("click", () => {
  const stepDiv = createMoveStep(sequence.length, renderTimeline, 'Y');
  sequenceList.appendChild(stepDiv);
  renderTimeline();
});


runBtn.addEventListener("click", async () => {
  let output = sequence.map(step => step.export());
  output = categorizeMovementSteps(output);
  
  try {
    const res = await fetch('/run_sequence', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(output)
    });
    const text = await res.text();
    console.log("✅ Backend says:", text);
  } catch (err) {
    console.error("❌ Error sending sequence:", err);
  }
});

stopBtn.addEventListener("click", async () => {
  console.warn("🛑 Sending stop command...");
  try {
    await fetch('/stop_sequence', { method: 'POST' });
    console.log("🛑 Stop command sent.");
  } catch (err) {
    console.error("❌ Failed to send stop command:", err);
  }
});

// Optional: manualMove from buttons
window.manualMove = (axis, direction) => {
  socket.emit("manual_move", { axis, direction });
};
