import { createMoveStep, createHoldStep } from './stepBuilder.js';
import { renderTimeline } from './timeline.js';
import { renumberSteps, sequence, categorizeMovementSteps } from './utils.js';
import { socket } from './socket.js';

const sequenceList = document.getElementById("sequence-list");
const addActionBtnZ = document.getElementById("add-action-z");
const addActionBtnX = document.getElementById("add-action-x");
const addActionBtnY = document.getElementById("add-action-y");

const runBtn = document.getElementById("run-sequence");
const stopBtn = document.getElementById("stop-sequence");

addActionBtnZ.addEventListener("click", () => {
  const stepDiv = createMoveStep(sequence.length, renderTimeline, 'Z');
  sequenceList.appendChild(stepDiv);
  renderTimeline();
});
addActionBtnX.addEventListener("click", () => {
  const stepDiv = createMoveStep(sequence.length, renderTimeline, 'X');
  sequenceList.appendChild(stepDiv);
  renderTimeline();
});
addActionBtnY.addEventListener("click", () => {
  const stepDiv = createMoveStep(sequence.length, renderTimeline, 'Y');
  sequenceList.appendChild(stepDiv);
  renderTimeline();
});

runBtn.addEventListener("click", async () => {
  let output = sequence.map(step => step.export());
  output = categorizeMovementSteps(output);

  try {
    const res = await fetch('/run_sequence', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(output)
    });
    const text = await res.text();
    console.log("✅ Backend says:", text);
  } catch (err) {
    console.error("❌ Error sending sequence:", err);
  }
});

stopBtn.addEventListener("click", async () => {
  console.warn("🛑 Sending stop command...");
  try {
    await fetch('/stop_sequence', { method: 'POST' });
    console.log("🛑 Stop command sent.");
  } catch (err) {
    console.error("❌ Failed to send stop command:", err);
  }
});

// ====== Jog Logic (manual align panel only!) ======
function setupJogButton(btnElem, axis, direction) {
  if (!btnElem) return;
  btnElem.addEventListener("mousedown", () => {
    socket.emit("manual_move_start", { axis, direction });
    btnElem.classList.add("jog-active");
  });
  btnElem.addEventListener("mouseup", () => {
    socket.emit("manual_move_stop", { axis });
    btnElem.classList.remove("jog-active");
  });
  btnElem.addEventListener("mouseleave", () => {
    socket.emit("manual_move_stop", { axis });
    btnElem.classList.remove("jog-active");
  });
  btnElem.addEventListener("touchstart", (e) => {
    e.preventDefault();
    socket.emit("manual_move_start", { axis, direction });
    btnElem.classList.add("jog-active");
  });
  btnElem.addEventListener("touchend", (e) => {
    e.preventDefault();
    socket.emit("manual_move_stop", { axis });
    btnElem.classList.remove("jog-active");
  });
}

// Keyboard support: only if NOT editing any input/textarea/select or in sequence builder
const jogging = { X: false, Y: false, Z: false };
const keyToAxisDir = {
  ArrowLeft: { axis: "X", direction: false, btnId: "jog-x-left" },
  ArrowRight: { axis: "X", direction: true, btnId: "jog-x-right" },
  ArrowUp: { axis: "Y", direction: false, btnId: "jog-y-up" },
  ArrowDown: { axis: "Y", direction: true, btnId: "jog-y-down" },
  KeyZ: { axis: "Z", direction: false, btnId: "jog-z-up" },
  KeyX: { axis: "Z", direction: true, btnId: "jog-z-down" }
};

function isTextInputFocused() {
  const el = document.activeElement;
  return el && (
    el.tagName === "INPUT" ||
    el.tagName === "TEXTAREA" ||
    el.tagName === "SELECT" ||
    el.isContentEditable ||
    (el.closest && el.closest(".sequence-step, .sb-arrow-up, .sb-arrow-down"))
  );
}

window.addEventListener("keydown", (e) => {
  if (isTextInputFocused()) return;
  const mapping = keyToAxisDir[e.code] || keyToAxisDir[e.key];
  if (mapping && !jogging[mapping.axis]) {
    jogging[mapping.axis] = true;
    socket.emit("manual_move_start", { axis: mapping.axis, direction: mapping.direction });
    if (mapping.btnId) {
      const btn = document.getElementById(mapping.btnId);
      if (btn) btn.classList.add("jog-active");
    }
  }
});
window.addEventListener("keyup", (e) => {
  if (isTextInputFocused()) return;
  const mapping = keyToAxisDir[e.code] || keyToAxisDir[e.key];
  if (mapping && jogging[mapping.axis]) {
    jogging[mapping.axis] = false;
    socket.emit("manual_move_stop", { axis: mapping.axis });
    if (mapping.btnId) {
      const btn = document.getElementById(mapping.btnId);
      if (btn) btn.classList.remove("jog-active");
    }
  }
});

window.addEventListener("DOMContentLoaded", () => {
  setupJogButton(document.getElementById("jog-x-left"), "X", false);
  setupJogButton(document.getElementById("jog-x-right"), "X", true);
  setupJogButton(document.getElementById("jog-y-up"), "Y", false);
  setupJogButton(document.getElementById("jog-y-down"), "Y", true);
  setupJogButton(document.getElementById("jog-z-up"), "Z", false);
  setupJogButton(document.getElementById("jog-z-down"), "Z", true);
});

window.tareForceSensor = function() {
  socket.emit("tare_force_sensor");
};