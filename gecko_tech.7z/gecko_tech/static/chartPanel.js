let chart = null;
let startTime = null;
let collecting = false;

// Helper: Set Chart.js colors based on theme
function updateChartTheme(theme) {
  if (!chart) return;
  const isDark = theme === 'dark';
  chart.options.plugins.legend.labels.color = isDark ? '#fff' : '#222';
  chart.options.scales.x.ticks.color = isDark ? '#fff' : '#222';
  chart.options.scales.x.grid.color = isDark ? '#444' : '#ddd';
  chart.options.scales.x.title.color = isDark ? '#fff' : '#222';
  chart.options.scales.y.ticks.color = isDark ? '#fff' : '#222';
  chart.options.scales.y.grid.color = isDark ? '#444' : '#ddd';
  chart.options.scales.y.title.color = isDark ? '#fff' : '#222';
  chart.update();
}

// Watch for theme changes
function listenForThemeChanges() {
  const applyTheme = () => {
    const theme = document.body.getAttribute('data-theme') || 'light';
    updateChartTheme(theme);
  };
  // Listen for manual toggle
  const themeToggle = document.getElementById('theme-toggle');
  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      setTimeout(applyTheme, 50);
    });
  }
  window.addEventListener('DOMContentLoaded', applyTheme);
}

export function initChartPanel() {
  const container = document.getElementById("chart-panel");
  if (!container) return;

  container.innerHTML = `
    <div id="chart-stack" style="
      display: flex;
      flex-direction: column;
      gap: 0.5em;
      padding: 0.5em;
      overflow-y: auto;
      max-height: 100%;
    "></div>
  `;
  listenForThemeChanges();
}

export function startPlotting() {
  startTime = Date.now();
  collecting = true;

  const canvas = document.createElement("canvas");
  canvas.width = 400;
  canvas.height = 200;
  const ctx = canvas.getContext("2d");

  const chartStack = document.getElementById("chart-stack");
  chartStack.prepend(canvas);

  const theme = document.body.getAttribute('data-theme') || 'light';
  const isDark = theme === 'dark';

  chart = new Chart(ctx, {
    type: 'line',
    data: {
      datasets: [{
        label: 'Fz (N)',
        data: [],
        borderColor: isDark ? '#bb86fc' : '#2196F3',
        tension: 0.2,
        fill: false,
        pointRadius: 0
      }]
    },
    options: {
      responsive: false,
      animation: false,
      plugins: {
        legend: { display: false, labels: { color: isDark ? '#fff' : '#222' } }
      },
      scales: {
        x: {
          type: 'linear',
          title: { display: true, text: 'Time (s)', color: isDark ? '#fff' : '#222' },
          ticks: { stepSize: 1, color: isDark ? '#fff' : '#222' },
          grid: { color: isDark ? '#444' : '#ddd' }
        },
        y: {
          title: { display: true, text: 'Fz (N)', color: isDark ? '#fff' : '#222' },
          min: -10,
          max: 20,
          ticks: { stepSize: 5, color: isDark ? '#fff' : '#222' },
          grid: { color: isDark ? '#444' : '#ddd' }
        }
      }
    }
  });
}

export function stopPlotting() {
  collecting = false;
}

export function pushForce(fz) {
  if (!collecting || !chart) return;
  const t = (Date.now() - startTime) / 1000;
  chart.data.datasets[0].data.push({ x: t, y: fz });
  chart.update('none');
}