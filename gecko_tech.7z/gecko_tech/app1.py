from flask import Flask, request, send_from_directory, jsonify
from flask_socketio import SocketIO
import threading, time
import RPi.GPIO as GPIO
import serial
import struct
from datetime import datetime

# === Global State ===
stop_threads = False
latest_force = {"Fx": 0.0, "Fy": 0.0, "Fz": 0.0}
sequence_running = False
serial_lock = threading.Lock()
MAX_FORCE_SENSOR_LIMIT = 10 #10 Newtons

# === Flask & SocketIO Setup ===
app = Flask(__name__, static_folder='static')
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# === GPIO Setup ===
GPIO.setmode(GPIO.BCM)
AXES = {
    "X": (24, 25),
    "Y": (16, 26),
    "Z": (27, 17),
}
for step_pin, dir_pin in AXES.values():
    GPIO.setup(step_pin, GPIO.OUT, initial=GPIO.LOW)
    GPIO.setup(dir_pin, GPIO.OUT, initial=GPIO.LOW)

# === Serial Sensor Setup ===
SERIAL_PORT = '/dev/ttyUSB0'
BAUDRATE = 115200
CALIBRATION_FACTORS = {'Fx': 10.0 / 0.5, 'Fy': 10.0 / 0.5, 'Fz': 10.0 / 0.5}

ser = serial.Serial(SERIAL_PORT, BAUDRATE, timeout=1)
with serial_lock:
    ser.write(b'\x23')
    time.sleep(0.1)
    ser.write(b'\x26\x01\x62\x65\x72\x6C\x69\x6E')
    time.sleep(0.1)
    ser.write(b'\x12\xA6')  # 12.5 Hz
    time.sleep(0.1)
    ser.write(b'\x24')
print("Serial sensor initialized")

# === Read Force Function ===
def read_force():
    with serial_lock:
        frame = ser.read(11)
    if len(frame) != 11 or frame[0] != 0xA5:
        return None
    fx = struct.unpack('>H', frame[1:3])[0]
    fy = struct.unpack('>H', frame[3:5])[0]
    fz = struct.unpack('>H', frame[5:7])[0]
    def raw_to_mv_v(raw): return (raw - 32768) / 32768 * 2.0
    return {
        'Fx': round(raw_to_mv_v(fx) * CALIBRATION_FACTORS['Fx'], 2),
        'Fy': round(raw_to_mv_v(fy) * CALIBRATION_FACTORS['Fy'], 2),
        'Fz': round(raw_to_mv_v(fz) * CALIBRATION_FACTORS['Fz'], 2)
    }

# === Force Poller Thread ===
def force_poller():
    print("Starting force poller...")
    while not stop_threads:
        data = read_force()
        if data:
            latest_force.update(data)
            socketio.emit("force", latest_force)
            print(f"[emit] force {latest_force}")

        time.sleep(0.05)


# def hold_force_for(duration: float):
#     start = time.time()
#     while time.time() - start < duration:
#         if not sequence_running:
#             break
#         time.sleep(0.1)

# def move_multiple_axes(axes_dict):
#     threads = []
#     for axis, config in axes_dict.items():
#         t = threading.Thread(
#             target=move_until_force,
#             args=(
#                 axis,
#                 config.get("direction") == "positive",
#                 config.get("triggers", []),
#                 1.0 / max(0.01, config.get("speed", 1.0) * 100)
#             ),
#             daemon=True
#         )
#         threads.append(t)
#         t.start()

#     for t in threads:
#         while t.is_alive():
#             if sequence_running == False:
#                 return
#             time.sleep(0.01)




def check_if_trigger_fired(trigger, duration):
    # case: if it is a force trigger
    if '(N)' in trigger['triggerType']:
        force_trigger_type = trigger['triggerType'].split(' (N)')[0] # example: Fy (N) => Fy, Fz (N) => Fz
        if (latest_force.get(force_trigger_type) >= trigger['value'] or latest_force.get(force_trigger_type) >= MAX_FORCE_SENSOR_LIMIT): #also return true if the current force is outside of sensor tolerance
            # halt movement
            return True
    
    elif 'duration' in trigger['triggerType']:
        if trigger['value'] >= duration:
            # force hold has reached its intended time
            return True
    
    elif '(mm)' in trigger['triggerType']:
        # check distances along each axis
        pass
    
    return False



def move_axis(step_pin, dir_pin, direction, step_size): # pulse width is dependent on the speed at which 
    
    # print('move: ', step_pin, dir_pin, direction, step_size/1000)
    GPIO.output(dir_pin, GPIO.HIGH if direction == 'positive' else GPIO.LOW)
    GPIO.output(step_pin, GPIO.HIGH)
    time.sleep(step_size/1000) # step_size in (ms)
    
    GPIO.output(step_pin, GPIO.LOW)
    time.sleep(1/1000) # by default set it to 1ms

    return


def hold_force(axis, threshold, step_pin, dir_pin, direction):
    step_pin, dir_pin = AXES[axis]
    force_axis = 'F' + axis.lower() # X => Fx

    while sequence_running:
        if abs(latest_force.get(force_axis) - threshold) <= 0.1: # if force along this axis is within tolerance
           return # force is within tolerance, exit from this function
        
        elif (latest_force.get(force_axis) > threshold):
            # making negative movement along this axis to reduce latest force along this axis
            move_axis(step_pin, dir_pin, 'positive', 20) # use 5ms step size  
        
        elif latest_force.get(force_axis) < threshold:
            # making positive movement along this axis to increase latest force along this axis
            move_axis(step_pin, dir_pin, 'negative', 20) # use 5ms step size





# === Steps Execution ===
def execute_steps_along_axis(axis, steps):
    for s in range(len(steps)):
        step = steps[s]
        data = step['data']
        move_type = step['type']
        direction = data['direction']
        data['holdThreshold'] = float(data['holdThreshold']) # example: '0.001' => 0.001

        # step initiation log
        socketio.emit("log", f"{axis}: Step {s} is initiated.")

        step_pin, dir_pin = AXES[axis]
        trigger_fired = False
        hold_trigger_fired = False

        while sequence_running:
            if trigger_fired == False:
                # 1. check all triggers, if anyone is true? halt movement!
                for trig in data['triggers']:
                    if check_if_trigger_fired(trig, 0): # temp fix
                        socketio.emit("log", f"Axis {axis}: {trig['triggerType']} ≥ {trig['value']}N, breaking movement.")
                        trigger_fired = True
                        break

            if trigger_fired == False:
                # if none of the triggers fired
                # initiate (keep) movement
                move_axis(step_pin, dir_pin, direction ,data['stepSize'])
            else:
                # check if we need to hold a force along this axis?
                if data['holdThreshold'] != 'NaN':

                    start_time = time.time()
                    end_time = 0

                    # emitting hold state notifcaition
                    socketio.emit("log", f'Holding force: F{axis.lower()} = {data["holdThreshold"]}N')

                    # there is a hold state
                    while sequence_running:
                        # now check if there is a holding case
                        if hold_trigger_fired == False:
                            # check if any of the triggers is True
                            for hold_trig in data['holdTriggers']:
                                if check_if_trigger_fired(hold_trig, end_time - start_time):
                                    hold_trigger_fired = True
                                    socketio.emit("log", f"Axis {axis}: {hold_trig['triggerType']} ≥ {hold_trig['value']}N, breaking force hold.")
                                    break

                        if hold_trigger_fired == False:
                            # maintain force through movement
                            hold_force(axis, data['holdThreshold'], step_pin, dir_pin, direction) # hold force by micro-movements in this axis
                            end_time = time.time()
                else:
                    socketio.emit("log", f"{axis}: Step {s} is completed!")
                    break # get to the next step!!
            




# === Sequence Execution ===
def run_dynamic_sequence(sequence):
    global sequence_running
    if sequence_running:
        return
    sequence_running = True
        
    socketio.emit("log", "Sequence started")
    threads = []
    for axis, steps in sequence.items():
        # for i, steps in enumerate(sequence[axis]):
        if not sequence_running:
            socketio.emit("log", "Sequence manually stopped")
            break
        
        # if there no steps along an axis:
        if len(steps) == 0:
            continue

        # just feed the list of actions along each axis to apropriate thread                
        t = threading.Thread(
            target=execute_steps_along_axis,
            args=(axis, steps)
        )
        t.start(); # non blocking thread for each axis
        threads.append(t)
        # action = step.get("type") or step.get("action")
        # socketio.emit("log", f"Step {i+1}: {action}")

        # if action == "hold":
        #     hold_force_for(float(step["duration"]))
        #     socketio.emit("log", f"⏸Hold complete ({step['duration']}s)")
        # elif action == "move-multiple-axes":
        #     move_multiple_axes(step["axes"])
        # else:
            # socketio.emit("log", f"Unknown action: {action}")

    # all threads are launched
    for t in threads:
        while t.is_alive():
            if sequence_running == False:
                return
            time.sleep(0.1) # 100ms

    # if sequence_running:
    #     socketio.emit("log", "Sequence complete")



# === Flask Routes ===
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/live_force')
def live_force():
    return jsonify(latest_force)

@app.route('/run_sequence', methods=['POST'])
def run_sequence():
    raw = request.get_json()
    print('raw: ', raw)
    # if not isinstance(raw, list):
    #     return "Invalid format", 400
    parsed = raw

    socketio.start_background_task(run_dynamic_sequence, parsed)
    return "Sequence started"

@app.route('/stop_sequence', methods=['POST'])
def stop_sequence():
    global sequence_running
    sequence_running = False
    return "Stopping"

@socketio.on("manual_move")
def handle_manual_move(data):
    axis = data.get("axis")
    direction = bool(data.get("direction"))
    if axis not in AXES:
        socketio.emit("log", f"Invalid axis: {axis}")
        return
    socketio.emit("log", f"🔧 Manual move on {axis} axis ({'+' if direction else '-'})")
    socketio.start_background_task(move_until_force, axis, direction, [], 0.001)

# === Launch App ===
if __name__ == '__main__':
    try:
        threading.Thread(target=force_poller, daemon=True).start()
        print("Flask-SocketIO server starting...")
        socketio.run(app, host='0.0.0.0', port=5000)
    finally:
        stop_threads = True
        time.sleep(0.1)
        GPIO.cleanup()
        ser.close()
        print("Clean exit")