from flask import Flask, request, send_from_directory, jsonify
from flask_socketio import SocketIO
import threading, time
import RPi.GPIO as GPIO
import serial
import struct

# === Global State ===
stop_threads = False
latest_force = {"Fx": 0.0, "Fy": 0.0, "Fz": 0.0}
sequence_running = False
serial_lock = threading.Lock()
MAX_FORCE_SENSOR_LIMIT = 10  # 10 Newtons
motor_check_status = {"X": False, "Y": False, "Z": False}

# === Flask & SocketIO Setup ===
app = Flask(__name__, static_folder='static')
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# === GPIO Setup ===
GPIO.setmode(GPIO.BCM)
AXES = {
    "X": (24, 25),
    "Y": (16, 26),
    "Z": (27, 17),
}
for step_pin, dir_pin in AXES.values():
    GPIO.setup(step_pin, GPIO.OUT, initial=GPIO.LOW)
    GPIO.setup(dir_pin, GPIO.OUT, initial=GPIO.LOW)

# === Per-axis direction: which direction INCREASES force for this axis? ===
# You MUST test this and set it right!
AXIS_FORCE_INCREASES_WITH = {
    "X": "positive",
    "Y": "positive",
    "Z": "negative",  # <-- If your Z 'negative' increases Fz; change if needed!
}

# === Serial Sensor Setup ===
SERIAL_PORT = '/dev/ttyUSB0'
BAUDRATE = 115200
CALIBRATION_FACTORS = {'Fx': 10.0 / 0.5, 'Fy': 10.0 / 0.5, 'Fz': 10.0 / 0.5}

ser = serial.Serial(SERIAL_PORT, BAUDRATE, timeout=1)
with serial_lock:
    ser.write(b'\x23')
    time.sleep(0.1)
    ser.write(b'\x26\x01\x62\x65\x72\x6C\x69\x6E')
    time.sleep(0.1)
    ser.write(b'\x12\xA6')  # 12.5 Hz
    time.sleep(0.1)
    ser.write(b'\x24')
print("Serial sensor initialized")

# === Read Force Function ===
def read_force():
    with serial_lock:
        frame = ser.read(11)
    if len(frame) != 11 or frame[0] != 0xA5:
        return None
    fx = struct.unpack('>H', frame[1:3])[0]
    fy = struct.unpack('>H', frame[3:5])[0]
    fz = struct.unpack('>H', frame[5:7])[0]
    def raw_to_mv_v(raw): return (raw - 32768) / 32768 * 2.0
    return {
        'Fx': round(raw_to_mv_v(fx) * CALIBRATION_FACTORS['Fx'], 2),
        'Fy': round(raw_to_mv_v(fy) * CALIBRATION_FACTORS['Fy'], 2),
        'Fz': round(raw_to_mv_v(fz) * CALIBRATION_FACTORS['Fz'], 2)
    }

# === Force Poller Thread ===
def force_poller():
    print("Starting force poller...")
    while not stop_threads:
        data = read_force()
        if data:
            latest_force.update(data)
            socketio.emit("force", latest_force)
        time.sleep(0.05)

# === Motor Check Function ===
def motor_check():
    global motor_check_status
    motor_check_status = {"X": False, "Y": False, "Z": False}
    socketio.emit("log", "Starting motor check sequence...")

    def move_axis_forward_backward(axis):
        step_pin, dir_pin = AXES[axis]
        steps_fwd = 0
        steps_bwd = 0

        GPIO.output(dir_pin, GPIO.HIGH)  # Forward
        start_time = time.time()
        while time.time() - start_time < 2.0:
            GPIO.output(step_pin, GPIO.HIGH)
            time.sleep(0.01)
            GPIO.output(step_pin, GPIO.LOW)
            time.sleep(0.01)
            steps_fwd += 1

        GPIO.output(dir_pin, GPIO.LOW)  # Reverse
        start_time = time.time()
        while time.time() - start_time < 2.0:
            GPIO.output(step_pin, GPIO.HIGH)
            time.sleep(0.01)
            GPIO.output(step_pin, GPIO.LOW)
            time.sleep(0.01)
            steps_bwd += 1

        motor_check_status[axis] = (steps_fwd > 0 and steps_bwd > 0)
        socketio.emit(
            "log",
            f"{axis} motor test {'Motor validation successful' if motor_check_status[axis] else 'Motor validation failed'} "
            f"(forward steps: {steps_fwd}, backward steps: {steps_bwd})"
        )

    threads = []
    for axis in ["X", "Y", "Z"]:
        t = threading.Thread(target=move_axis_forward_backward, args=(axis,))
        t.start()
        threads.append(t)
    for t in threads:
        t.join()

    socketio.emit("motor_check_status", motor_check_status)
    socketio.emit("log", "Motor check sequence complete")

# === Trigger Function ===
def check_if_trigger_fired(trigger, duration):
    if '(N)' in trigger['triggerType']:
        force_trigger_type = trigger['triggerType'].split(' (N)')[0]
        value = float(trigger['value'])
        if (latest_force.get(force_trigger_type) >= value or latest_force.get(force_trigger_type) >= MAX_FORCE_SENSOR_LIMIT):
            return True
    elif 'duration' in trigger['triggerType']:
        if trigger['value'] >= duration:
            return True
    return False

def move_axis(step_pin, dir_pin, direction, step_size):
    GPIO.output(dir_pin, GPIO.HIGH if direction == 'positive' else GPIO.LOW)
    GPIO.output(step_pin, GPIO.HIGH)
    time.sleep(step_size / 1000)
    GPIO.output(step_pin, GPIO.LOW)
    time.sleep(1 / 1000)
    return

# === Robust Hold Force Controller ===
def hold_force(axis, threshold, step_pin, dir_pin):
    force_axis = 'F' + axis.lower()
    tolerance = 0.1
    step_size = 20  # ms pulse

    # Map which direction increases/decreases the force
    increase_dir = AXIS_FORCE_INCREASES_WITH[axis]
    decrease_dir = 'negative' if increase_dir == 'positive' else 'positive'

    while sequence_running:
        current_force = latest_force.get(force_axis)
        diff = current_force - threshold

        if abs(diff) <= tolerance:
            time.sleep(0.12)
            return
        elif diff > tolerance:
            # Too much force, step in decrease_dir
            move_axis(step_pin, dir_pin, decrease_dir, step_size)
        elif diff < -tolerance:
            # Too little force, step in increase_dir
            move_axis(step_pin, dir_pin, increase_dir, step_size)

def hold_force_for(duration: float):
    start = time.time()
    while time.time() - start < duration:
        if not sequence_running:
            break
        time.sleep(0.1)

def move_until_force(axis, direction, triggers, speed):
    step_pin, dir_pin = AXES[axis]
    force_axis = 'F' + axis.lower()
    GPIO.output(dir_pin, GPIO.HIGH if direction else GPIO.LOW)

    while sequence_running:
        for trigger in triggers:
            if check_if_trigger_fired(trigger, 0):
                socketio.emit("log", f"Axis {axis}: {trigger['triggerType']} ≥ {trigger['value']}N, stopping")
                return
        GPIO.output(step_pin, GPIO.HIGH)
        time.sleep(1 / speed)
        GPIO.output(step_pin, GPIO.LOW)
        time.sleep(1 / speed)

# === Steps Execution ===
def execute_steps_along_axis(axis, steps):
    for s in range(len(steps)):
        next_step = False
        step = steps[s]
        data = step['data']
        move_type = step['type']
        direction = data['direction']
        data['holdThreshold'] = float(data['holdThreshold'])

        socketio.emit("log", f"{axis}: Step {s} is initiated.")

        step_pin, dir_pin = AXES[axis]
        trigger_fired = False
        hold_trigger_fired = False

        while sequence_running:
            if next_step:
                break
            if not trigger_fired:
                for trig in data['triggers']:
                    if check_if_trigger_fired(trig, 0):
                        socketio.emit("log", f"Axis {axis}: {trig['triggerType']} ≥ {trig['value']}N, breaking movement.")
                        trigger_fired = True
                        break

            if not trigger_fired:
                move_axis(step_pin, dir_pin, direction, data['stepSize'])
            else:
                if data['holdThreshold'] != float('NaN'):
                    start_time = time.time()
                    end_time = 0
                    socketio.emit("log", f'Holding force: F{axis.lower()} = {data["holdThreshold"]}N')
                    while sequence_running:
                        if not hold_trigger_fired:
                            for hold_trig in data['holdTriggers']:
                                if check_if_trigger_fired(hold_trig, end_time - start_time):
                                    hold_trigger_fired = True
                                    socketio.emit("log", f"Axis {axis}: {hold_trig['triggerType']} ≥ {hold_trig['value']}N, breaking force hold.")
                                    next_step = True
                                    break
                        if not hold_trigger_fired:
                            hold_force(axis, data['holdThreshold'], step_pin, dir_pin)
                            end_time = time.time()
                        if next_step:
                            break
                else:
                    socketio.emit("log", f"{axis}: Step {s} is completed!")
                    break

# === Sequence Execution ===
def run_dynamic_sequence(sequence):
    global sequence_running
    if sequence_running:
        return
    sequence_running = True

    socketio.emit("log", "Sequence started")
    threads = []
    for axis, steps in sequence.items():
        if not sequence_running:
            socketio.emit("log", "Sequence manually stopped")
            break
        if len(steps) == 0:
            continue
        t = threading.Thread(
            target=execute_steps_along_axis,
            args=(axis, steps)
        )
        t.start()
        threads.append(t)
    for t in threads:
        while t.is_alive():
            if not sequence_running:
                return
            time.sleep(0.1)

# === Flask Routes ===
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/live_force')
def live_force():
    return jsonify(latest_force)

@app.route('/run_sequence', methods=['POST'])
def run_sequence():
    raw = request.get_json()
    print('raw: ', raw)
    parsed = raw
    socketio.start_background_task(run_dynamic_sequence, parsed)
    return "Sequence started"

@app.route('/stop_sequence', methods=['POST'])
def stop_sequence():
    global sequence_running
    sequence_running = False
    return "Stopping"

@app.route('/motor_check')
def run_motor_check():
    socketio.start_background_task(motor_check)
    return "Motor check started"

# === SocketIO manual move/jog (optional) ===
@socketio.on("manual_move")
def handle_manual_move(data):
    axis = data.get("axis")
    direction = bool(data.get("direction"))
    if axis not in AXES:
        socketio.emit("log", f"Invalid axis: {axis}")
        return
    socketio.emit("log", f"🔧 Manual move on {axis} axis ({'+' if direction else '-'})")
    socketio.start_background_task(move_until_force, axis, direction, [], 0.001)

# === App Start ===
if __name__ == '__main__':
    try:
        threading.Thread(target=force_poller, daemon=True).start()
        print("Flask-SocketIO server starting...")
        socketio.run(app, host='0.0.0.0', port=5000)
    finally:
        stop_threads = True
        time.sleep(0.1)
        GPIO.cleanup()
        ser.close()
        print("Clean exit")
