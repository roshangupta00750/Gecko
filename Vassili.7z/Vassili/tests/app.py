#!/usr/bin/env python3
from flask import Flask, request, send_from_directory, abort
import threading, time
import RPi.GPIO as GPIO

# ——— GPIO setup ———
GPIO.setmode(GPIO.BCM)
AXES = {
    "X": (16, 26),
    "Y": (24, 25),
    "Z": (27, 17),
}
for step_pin, dir_pin in AXES.values():
    GPIO.setup(step_pin, GPIO.OUT, initial=GPIO.LOW)
    GPIO.setup(dir_pin,  GPIO.OUT, initial=GPIO.LOW)

step_delay = 0.001  # seconds between edges → adjust speed
moving = {ax: False for ax in AXES}

def _stepper_loop(axis: str, direction: bool):
    step_pin, dir_pin = AXES[axis]
    GPIO.output(dir_pin, GPIO.HIGH if direction else GPIO.LOW)
    while moving[axis]:
        GPIO.output(step_pin, GPIO.HIGH)
        time.sleep(step_delay)
        GPIO.output(step_pin, GPIO.LOW)
        time.sleep(step_delay)

# ——— Flask app ———
app = Flask(__name__, static_folder='.')

@app.route('/')
def index():
    # serves index.html from the same folder
    return send_from_directory('.', 'index.html')

@app.route('/start')
def start():
    axis = request.args.get('axis', '').upper()
    dir_flag = request.args.get('dir')
    if axis not in AXES or dir_flag not in ('0','1'):
        abort(400)
    direction = (dir_flag == '1')
    if not moving[axis]:
        moving[axis] = True
        threading.Thread(target=_stepper_loop, args=(axis, direction), daemon=True).start()
    return 'OK'

@app.route('/stop')
def stop():
    axis = request.args.get('axis', '').upper()
    if axis not in AXES:
        abort(400)
    moving[axis] = False
    return 'OK'

if __name__ == '__main__':
    try:
        app.run(host='0.0.0.0', port=5000)
    finally:
        GPIO.cleanup()
