#!/usr/bin/env python3
from flask import Flask, request, send_from_directory, abort
import threading, time
import RPi.GPIO as GPIO
import serial
import struct

# ——— GPIO setup ———
GPIO.setmode(GPIO.BCM)
AXES = {
    "X": (16, 26),
    "Y": (24, 25),
    "Z": (27, 17),
}
for step_pin, dir_pin in AXES.values():
    GPIO.setup(step_pin, GPIO.OUT, initial=GPIO.LOW)
    GPIO.setup(dir_pin,  GPIO.OUT, initial=GPIO.LOW)

step_delay = 0.001  # seconds between edges → adjust speed
moving = {ax: False for ax in AXES}

def _stepper_loop(axis: str, direction: bool):
    step_pin, dir_pin = AXES[axis]
    GPIO.output(dir_pin, GPIO.HIGH if direction else GPIO.LOW)
    while moving[axis]:
        GPIO.output(step_pin, GPIO.HIGH)
        time.sleep(step_delay)
        GPIO.output(step_pin, GPIO.LOW)
        time.sleep(step_delay)

# ——— GSV-4 force sensor setup ———
SERIAL_PORT = '/dev/ttyUSB0'  # adjust this!
BAUDRATE = 115200
CALIBRATION_FACTORS = {
    'Fx': 10.0 / 0.5,
    'Fy': 10.0 / 0.5,
    'Fz': 10.0 / 0.5
}

ser = serial.Serial(SERIAL_PORT, BAUDRATE, timeout=1)
ser.write(b'\x23')
time.sleep(0.1)
ser.write(b'\x26\x01\x62\x65\x72\x6C\x69\x6E')
time.sleep(0.1)
ser.write(b'\x24')

def read_force():
    frame = ser.read(11)
    if len(frame) != 11 or frame[0] != 0xA5:
        return None

    fx_raw = struct.unpack('>H', frame[1:3])[0]
    fy_raw = struct.unpack('>H', frame[3:5])[0]
    fz_raw = struct.unpack('>H', frame[5:7])[0]

    def raw_to_mv_v(raw, scale=2.0):
        return (raw - 32768) / 32768 * scale

    fx_mv_v = raw_to_mv_v(fx_raw)
    fy_mv_v = raw_to_mv_v(fy_raw)
    fz_mv_v = raw_to_mv_v(fz_raw)

    fx_n = fx_mv_v * CALIBRATION_FACTORS['Fx']
    fy_n = fy_mv_v * CALIBRATION_FACTORS['Fy']
    fz_n = fz_mv_v * CALIBRATION_FACTORS['Fz']

    return {'Fx': round(fx_n, 2), 'Fy': round(fy_n, 2), 'Fz': round(fz_n, 2)}

# ——— Flask app ———
app = Flask(__name__, static_folder='.')

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/start')
def start():
    axis = request.args.get('axis', '').upper()
    dir_flag = request.args.get('dir')
    if axis not in AXES or dir_flag not in ('0','1'):
        abort(400)
    direction = (dir_flag == '1')
    if not moving[axis]:
        moving[axis] = True
        threading.Thread(target=_stepper_loop, args=(axis, direction), daemon=True).start()
    return 'OK'

@app.route('/stop')
def stop():
    axis = request.args.get('axis', '').upper()
    if axis not in AXES:
        abort(400)
    moving[axis] = False
    return 'OK'

@app.route('/force')
def force():
    data = read_force()
    if data is None:
        return {'error': 'No data'}, 500
    return data

if __name__ == '__main__':
    try:
        app.run(host='0.0.0.0', port=5000)
    finally:
        GPIO.cleanup()
        ser.close()
