import serial
import struct
import time

# Settings
SERIAL_PORT = '/dev/ttyUSB0'  # adjust this
BAUDRATE = 115200

CALIBRATION_FACTORS = {
    'Fx': 10.0 / 0.5,  # N per mV/V (example)
    'Fy': 10.0 / 0.5,
    'Fz': 10.0 / 0.5
}

# Conversion
def raw_to_mv_v(raw, scale=2.0):
    return (raw - 32768) / 32768 * scale

# Setup
ser = serial.Serial(SERIAL_PORT, BAUDRATE, timeout=1)
ser.write(b'\x23')
time.sleep(0.1)
ser.write(b'\x26\x01\x62\x65\x72\x6C\x69\x6E')
time.sleep(0.1)
ser.write(b'\x24')

# Loop
try:
    while True:
        frame = ser.read(11)
        if len(frame) != 11 or frame[0] != 0xA5:
            continue

        fx_raw = struct.unpack('>H', frame[1:3])[0]
        fy_raw = struct.unpack('>H', frame[3:5])[0]
        fz_raw = struct.unpack('>H', frame[5:7])[0]

        fx_mv_v = raw_to_mv_v(fx_raw)
        fy_mv_v = raw_to_mv_v(fy_raw)
        fz_mv_v = raw_to_mv_v(fz_raw)

        fx_n = fx_mv_v * CALIBRATION_FACTORS['Fx']
        fy_n = fy_mv_v * CALIBRATION_FACTORS['Fy']
        fz_n = fz_mv_v * CALIBRATION_FACTORS['Fz']

        print(f"Fx: {fx_n:.2f} N\tFy: {fy_n:.2f} N\tFz: {fz_n:.2f} N")

        time.sleep(0.05)

except KeyboardInterrupt:
    print("Stopped.")
finally:
    ser.close()
