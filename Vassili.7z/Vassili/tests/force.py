#!/usr/bin/env python3

import serial
import struct
import time

# Settings
SERIAL_PORT = '/dev/ttyUSB0'  # Adjust if needed
BAUDRATE = 115200
CALIBRATION_FACTORS = {
    'Fx': 10.0 / 0.5,
    'Fy': 10.0 / 0.5,
    'Fz': 10.0 / 0.5
}

# Conversion helper
def raw_to_mv_v(raw, scale=2.0):
    return (raw - 32768) / 32768 * scale

# Init serial
ser = serial.Serial(SERIAL_PORT, BAUDRATE, timeout=1)

# Setup GSV-4
ser.write(b'\x23')  # stop
time.sleep(0.1)
ser.write(b'\x26\x01\x62\x65\x72\x6C\x69\x6E')  # set mode
time.sleep(0.1)
ser.write(b'\x24')  # start transmission

# Main loop
print("Reading GSV-4 force sensor (Ctrl+C to stop)")
try:
    while True:
        frame = ser.read(11)
        if len(frame) != 11 or frame[0] != 0xA5:
            continue  # skip invalid

        fx_raw = struct.unpack('>H', frame[1:3])[0]
        fy_raw = struct.unpack('>H', frame[3:5])[0]
        fz_raw = struct.unpack('>H', frame[5:7])[0]

        fx_mv_v = raw_to_mv_v(fx_raw)
        fy_mv_v = raw_to_mv_v(fy_raw)
        fz_mv_v = raw_to_mv_v(fz_raw)

        fx_n = fx_mv_v * CALIBRATION_FACTORS['Fx']
        fy_n = fy_mv_v * CALIBRATION_FACTORS['Fy']
        fz_n = fz_mv_v * CALIBRATION_FACTORS['Fz']

        print(f"Fx: {fx_mv_v:+.4f} mV/V | {fx_n:+.2f} N\t"
              f"Fy: {fy_mv_v:+.4f} mV/V | {fy_n:+.2f} N\t"
              f"Fz: {fz_mv_v:+.4f} mV/V | {fz_n:+.2f} N")

        time.sleep(0.05)  # ~20 Hz update

except KeyboardInterrupt:
    print("\nStopped.")

finally:
    ser.close()
