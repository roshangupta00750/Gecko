let sequence = [];
let notifiedForceCross = false;

// === WebSocket setup ===
const socket = io({
  transports: ['websocket']
});

socket.onAny((event, ...args) => {
  console.log("[socket received]", event, args);
});

socket.on("connect", () => {
  notify("✅ WebSocket connected");
});

socket.on("disconnect", () => {
  notify("⚠️ WebSocket disconnected");
});

socket.on("connect_error", (err) => {
  notify("❌ WebSocket error: " + err.message);
});

// === Backend logs
socket.on("log", (msg) => {
  notify(msg);
});

// === Force data from backend
socket.on("force", (data) => {
  console.log("FORCE DATA:", data);  // ✅ Debug
  document.getElementById('fx').innerText = data.Fx;
  document.getElementById('fy').innerText = data.Fy;
  document.getElementById('fz').innerText = data.Fz;

  if (data.Fz >= 5 && !notifiedForceCross) {
    notify(`⚠️ Fz reached ${data.Fz} N`);
    notifiedForceCross = true;
  } else if (data.Fz < 5) {
    notifiedForceCross = false;
  }
});

// === UI: Modal open logic
function openModal(type, index = -1) {
  document.getElementById('modal').style.display = 'flex';
  document.getElementById('actionType').value = type;
  document.getElementById('editIndex').value = index;

  document.getElementById('modalTitle').innerText = {
    move: 'Add Move',
    move_until: 'Add Move Until Force',
    hold: 'Add Hold Duration'
  }[type];

  // Default values
  document.getElementById('axis').value = 'X';
  document.getElementById('direction').value = '1';
  document.getElementById('steps').value = '100';
  document.getElementById('forceThreshold').value = '5';
  document.getElementById('forceAxis').value = 'Fz';
  document.getElementById('holdDuration').value = '2.0';
  document.getElementById('speed').value = '1.0';

  // Populate if editing
  if (index >= 0) {
    const item = sequence[index];
    document.getElementById('axis').value = item.axis || 'X';
    document.getElementById('direction').value = item.direction || '1';
    document.getElementById('steps').value = item.steps || '100';
    document.getElementById('forceThreshold').value = item.forceThreshold || '5';
    document.getElementById('forceAxis').value = item.forceAxis || 'Fz';
    document.getElementById('holdDuration').value = item.duration || '2.0';
    document.getElementById('speed').value = item.speed || '1.0';
  }

  // Field visibility
  document.getElementById('axisGroup').style.display = (type !== 'hold') ? 'block' : 'none';
  document.getElementById('directionGroup').style.display = (type !== 'hold') ? 'block' : 'none';
  document.getElementById('stepsGroup').style.display = (type !== 'hold') ? 'block' : 'none';
  document.getElementById('forceGroup').style.display = (type === 'move_until') ? 'block' : 'none';
  document.getElementById('holdGroup').style.display = (type === 'hold') ? 'block' : 'none';
  document.getElementById('speedGroup').style.display = (type !== 'hold') ? 'block' : 'none';
}

function closeModal() {
  document.getElementById('modal').style.display = 'none';
}

// === Save new or edited action
function saveAction() {
  const type = document.getElementById('actionType').value;
  const index = parseInt(document.getElementById('editIndex').value);
  let action = { action: type };

  if (type === 'move' || type === 'move_until') {
    action.axis = document.getElementById('axis').value;
    action.direction = parseInt(document.getElementById('direction').value);
    action.steps = parseInt(document.getElementById('steps').value);
    action.speed = parseFloat(document.getElementById('speed').value);
  }

  if (type === 'move_until') {
    action.forceAxis = document.getElementById('forceAxis').value;
    action.forceThreshold = parseFloat(document.getElementById('forceThreshold').value);
  }

  if (type === 'hold') {
    action.duration = parseFloat(document.getElementById('holdDuration').value);
  }

  if (index >= 0) {
    sequence[index] = action;
  } else {
    sequence.push(action);
  }

  renderSequence();
  closeModal();
}

// === Render sequence list
function renderSequence() {
  const ul = document.getElementById('sequence');
  ul.innerHTML = '';
  sequence.forEach((step, i) => {
    const li = document.createElement('li');
    li.innerHTML = `
      ${JSON.stringify(step)}
      <span class="action-buttons">
        <button onclick="openModal('${step.action}', ${i})">✏️</button>
        <button onclick="deleteAction(${i})">❌</button>
      </span>
    `;
    ul.appendChild(li);
  });
}

function deleteAction(index) {
  sequence.splice(index, 1);
  renderSequence();
}

// === Run sequence
async function runSequence() {
  try {
    notify("⏳ Sending sequence to backend...");
    const res = await fetch('/run_sequence', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(sequence)
    });
    const text = await res.text();
    notify("✅ " + text);
  } catch (err) {
    notify("❌ Error sending sequence: " + err);
  }
}

// === UI logger
function notify(msg) {
  const log = document.getElementById('log');
  const entry = document.createElement('li');
  entry.textContent = `${new Date().toLocaleTimeString()} — ${msg}`;
  log.insertBefore(entry, log.firstChild);
}
