window.addEventListener('DOMContentLoaded', () => {
  let sequence = [];
  let notifiedForceCross = false;

  const socket = io({ transports: ['websocket'] });

  socket.onAny((event, ...args) => {
    console.log("[socket received]", event, args);
  });

  socket.on("connect", () => {
    console.log("✅ WebSocket connected");
    notify("✅ WebSocket connected");
  });

  socket.on("disconnect", () => {
    console.warn("⚠️ WebSocket disconnected");
    notify("⚠️ WebSocket disconnected");
  });

  socket.on("connect_error", (err) => {
    console.error("❌ WebSocket error: ", err);
    notify("❌ WebSocket error: " + err.message);
  });

  socket.on("log", (msg) => {
    console.log("[log]", msg);
    notify(msg);
  });

  socket.on("force", (data) => {
    console.log("[force data received]", data);
    const fxEl = document.getElementById('fx');
    const fyEl = document.getElementById('fy');
    const fzEl = document.getElementById('fz');
    const tacho = document.getElementById('fzTacho');

    console.log("Tachometer DOM Element:", tacho);

    if (fxEl && fyEl && fzEl && tacho) {
      const fzValue = data.Fz.toFixed(2);
      fxEl.innerText = data.Fx.toFixed(2);
      fyEl.innerText = data.Fy.toFixed(2);
      fzEl.innerText = fzValue;

      tacho.textContent = fzValue;

      const glow = Math.min(1, data.Fz / 10);
      const red = Math.floor(255 * glow);
      const green = Math.floor(100 * (1 - glow));
      tacho.style.color = `rgb(${red},${green},100)`;

      console.log("Tachometer updated to:", fzValue);
    } else {
      console.warn("⚠️ Missing fx/fy/fz or fzTacho DOM elements");
    }

    if (data.Fz >= 5 && !notifiedForceCross) {
      notify(`⚠️ Fz reached ${data.Fz.toFixed(2)} N`);
      notifiedForceCross = true;
    } else if (data.Fz < 5) {
      notifiedForceCross = false;
    }
  });

  function manualMove(axis, direction) {
    console.log(`[manualMove] ${axis} ${direction === 1 ? "positive" : "negative"}`);
    socket.emit("manual_move", { axis, direction });
  }

  window.manualMove = manualMove; // expose to global for HTML buttons

  function openModal(type, index = -1) {
    document.getElementById('modal').style.display = 'flex';
    document.getElementById('actionType').value = type;
    document.getElementById('editIndex').value = index;

    document.getElementById('modalTitle').innerText = {
      move: 'Add Move',
      move_until: 'Add Move Until Force',
      hold: 'Add Hold Duration'
    }[type];

    document.getElementById('axis').value = 'X';
    document.getElementById('direction').value = '1';
    document.getElementById('steps').value = '100';
    document.getElementById('forceThreshold').value = '5';
    document.getElementById('forceAxis').value = 'Fz';
    document.getElementById('holdDuration').value = '2.0';
    document.getElementById('speed').value = '1.0';

    if (index >= 0) {
      const item = sequence[index];
      document.getElementById('axis').value = item.axis || 'X';
      document.getElementById('direction').value = item.direction || '1';
      document.getElementById('steps').value = item.steps || '100';
      document.getElementById('forceThreshold').value = item.forceThreshold || '5';
      document.getElementById('forceAxis').value = item.forceAxis || 'Fz';
      document.getElementById('holdDuration').value = item.duration || '2.0';
      document.getElementById('speed').value = item.speed || '1.0';
    }

    document.getElementById('axisGroup').style.display = (type !== 'hold') ? 'block' : 'none';
    document.getElementById('directionGroup').style.display = (type !== 'hold') ? 'block' : 'none';
    document.getElementById('stepsGroup').style.display = (type !== 'hold') ? 'block' : 'none';
    document.getElementById('forceGroup').style.display = (type === 'move_until') ? 'block' : 'none';
    document.getElementById('holdGroup').style.display = (type === 'hold') ? 'block' : 'none';
    document.getElementById('speedGroup').style.display = (type !== 'hold') ? 'block' : 'none';
  }

  function closeModal() {
    document.getElementById('modal').style.display = 'none';
  }

  window.openModal = openModal;
  window.closeModal = closeModal;

  function saveAction() {
    const type = document.getElementById('actionType').value;
    const index = parseInt(document.getElementById('editIndex').value);
    let action = { action: type };

    if (type === 'move' || type === 'move_until') {
      action.axis = document.getElementById('axis').value;
      action.direction = parseInt(document.getElementById('direction').value);
      action.steps = parseInt(document.getElementById('steps').value);
      action.speed = parseFloat(document.getElementById('speed').value);
    }

    if (type === 'move_until') {
      action.forceAxis = document.getElementById('forceAxis').value;
      action.forceThreshold = parseFloat(document.getElementById('forceThreshold').value);
    }

    if (type === 'hold') {
      action.duration = parseFloat(document.getElementById('holdDuration').value);
    }

    if (index >= 0) {
      sequence[index] = action;
    } else {
      sequence.push(action);
    }

    renderSequence();
    closeModal();
  }

  window.saveAction = saveAction;

  function renderSequence() {
    const ul = document.getElementById('sequence');
    ul.innerHTML = '';
    sequence.forEach((step, i) => {
      const li = document.createElement('li');
      li.innerHTML = `
        ${JSON.stringify(step)}
        <span class="action-buttons">
          <button onclick="openModal('${step.action}', ${i})">✏️</button>
          <button onclick="deleteAction(${i})">❌</button>
        </span>
      `;
      ul.appendChild(li);
    });
  }

  function deleteAction(index) {
    sequence.splice(index, 1);
    renderSequence();
  }

  window.deleteAction = deleteAction;

  async function runSequence() {
    try {
      notify("⏳ Sending sequence to backend...");
      const res = await fetch('/run_sequence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sequence)
      });
      const text = await res.text();
      notify("✅ " + text);
    } catch (err) {
      notify("❌ Error sending sequence: " + err);
    }
  }

  window.runSequence = runSequence;

  function notify(msg) {
    const log = document.getElementById('log');
    const entry = document.createElement('li');
    entry.textContent = `${new Date().toLocaleTimeString()} — ${msg}`;
    log.insertBefore(entry, log.firstChild);
  }
});
