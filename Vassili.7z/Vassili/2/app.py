from flask import Flask, request, send_from_directory, jsonify
from flask_socketio import SocketIO
import threading, time, eventlet
import RPi.GPIO as GPIO
import serial
import struct
from datetime import datetime

# === Global State ===
stop_threads = False
latest_force = {"Fx": 0.0, "Fy": 0.0, "Fz": 0.0}
sequence_running = False
serial_lock = threading.Lock()

# === Flask & SocketIO Setup ===
app = Flask(__name__, static_folder='static')
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='eventlet')

# === GPIO Setup ===
GPIO.setmode(GPIO.BCM)
AXES = {
    "X": (16, 26),
    "Y": (24, 25),
    "Z": (27, 17),
}
for step_pin, dir_pin in AXES.values():
    GPIO.setup(step_pin, GPIO.OUT, initial=GPIO.LOW)
    GPIO.setup(dir_pin, GPIO.OUT, initial=GPIO.LOW)

# === Serial Sensor Setup ===
SERIAL_PORT = '/dev/ttyUSB0'
BAUDRATE = 115200
CALIBRATION_FACTORS = {'Fx': 10.0 / 0.5, 'Fy': 10.0 / 0.5, 'Fz': 10.0 / 0.5}

ser = serial.Serial(SERIAL_PORT, BAUDRATE, timeout=1)
with serial_lock:
    ser.write(b'\x23')
    time.sleep(0.1)
    ser.write(b'\x26\x01\x62\x65\x72\x6C\x69\x6E')
    time.sleep(0.1)
    ser.write(b'\x12\xA6')  # 12.5 Hz
    time.sleep(0.1)
    ser.write(b'\x24')
print("✅ Serial sensor initialized")

# === Read Force Function ===
def read_force():
    with serial_lock:
        frame = ser.read(11)
    if len(frame) != 11 or frame[0] != 0xA5:
        return None
    fx = struct.unpack('>H', frame[1:3])[0]
    fy = struct.unpack('>H', frame[3:5])[0]
    fz = struct.unpack('>H', frame[5:7])[0]
    def raw_to_mv_v(raw): return (raw - 32768) / 32768 * 2.0
    return {
        'Fx': round(raw_to_mv_v(fx) * CALIBRATION_FACTORS['Fx'], 2),
        'Fy': round(raw_to_mv_v(fy) * CALIBRATION_FACTORS['Fy'], 2),
        'Fz': round(raw_to_mv_v(fz) * CALIBRATION_FACTORS['Fz'], 2)
    }

# === Force Poller Thread ===
def force_poller():
    print("📡 Starting force poller...")
    while not stop_threads:
        data = read_force()
        if data:
            latest_force.update(data)
            timestamp = datetime.now().strftime("[%H:%M:%S]")
            print(f"{timestamp} [emit] force {latest_force}")
            socketio.emit("force", latest_force)
        eventlet.sleep(0.05)

# === Movement Functions ===
def move_steps(axis: str, direction: bool, steps: int, delay: float):
    step_pin, dir_pin = AXES[axis]
    GPIO.output(dir_pin, GPIO.HIGH if direction else GPIO.LOW)
    for _ in range(steps):
        GPIO.output(step_pin, GPIO.HIGH)
        time.sleep(delay)
        GPIO.output(step_pin, GPIO.LOW)
        time.sleep(delay)
        eventlet.sleep(0)  # yield control

def move_until_force_or_steps(axis: str, direction: bool, max_steps: int, force_limit: float, force_axis: str, delay: float):
    step_pin, dir_pin = AXES[axis]
    GPIO.output(dir_pin, GPIO.HIGH if direction else GPIO.LOW)
    for _ in range(max_steps):

        #print(latest_force.get(force_axis, 0))
        #print(force_limit)
        print("in loop")
        if latest_force.get(force_axis, 0) >= force_limit:
            socketio.emit("log", f"🔻 Force limit reached on {force_axis}: {latest_force[force_axis]} N")
            break
        GPIO.output(step_pin, GPIO.HIGH)
        time.sleep(delay)
        GPIO.output(step_pin, GPIO.LOW)
        time.sleep(delay)
        eventlet.sleep(1)

def hold_force_for(duration: float):
    start = time.time()
    while time.time() - start < duration:
        eventlet.sleep(0.1)

# === Run Sequence ===
def run_dynamic_sequence(sequence):
    global sequence_running
    if sequence_running:
        return
    sequence_running = True
    try:
        socketio.emit("log", "✅ Sequence started")
        eventlet.sleep(0)

        for i, step in enumerate(sequence):
            action = step.get("action")
            delay = float(step.get("speed", 1.0)) / 1000

            desc = f"➡️ Step {i+1}: {action}"
            if action == "move":
                desc += f", axis {step['axis']}, dir {step['direction']}, steps {step['steps']}, speed {step['speed']}ms"
            elif action == "move_until":
                desc += f", axis {step['axis']}, dir {step['direction']}, steps {step['steps']}, until {step['forceAxis']} ≥ {step['forceThreshold']} N, speed {step['speed']}ms"
            elif action == "hold":
                desc += f", duration {step['duration']}s"
            socketio.emit("log", desc)
            eventlet.sleep(0)

            if action == "move":
                move_steps(step["axis"], bool(step["direction"]), int(step["steps"]), delay)
            elif action == "move_until":
                move_until_force_or_steps(
                    axis=step["axis"],
                    direction=bool(step["direction"]),
                    max_steps=int(step["steps"]),
                    force_limit=float(step["forceThreshold"]),
                    force_axis=step["forceAxis"],
                    delay=delay
                )
            elif action == "hold":
                hold_force_for(float(step["duration"]))
                socketio.emit("log", f"⏸️ Hold complete ({step['duration']}s)")
                eventlet.sleep(0)
            else:
                socketio.emit("log", f"⚠️ Unknown action: {action}")
                eventlet.sleep(0)

        socketio.emit("log", "✅ Sequence complete")
        eventlet.sleep(0)
    finally:
        sequence_running = False

# === Flask Routes ===
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/live_force')
def live_force():
    return jsonify(latest_force)

@app.route('/run_sequence', methods=['POST'])
def run_sequence():
    sequence = request.get_json()
    if not isinstance(sequence, list):
        return "Invalid format", 400
    socketio.start_background_task(run_dynamic_sequence, sequence)
    return "Sequence started"

@socketio.on("manual_move")
def handle_manual_move(data):
    axis = data.get("axis")
    direction = bool(data.get("direction"))
    if axis not in AXES:
        socketio.emit("log", f"❌ Invalid axis: {axis}")
        return
    socketio.emit("log", f"🔧 Manual move on {axis} axis ({'+' if direction else '-'})")
    socketio.start_background_task(move_steps, axis, direction, 100, 0.001)

# === Launch App ===
if __name__ == '__main__':
    try:
        socketio.start_background_task(force_poller)
        print("🚀 Flask-SocketIO server starting...")
        socketio.run(app, host='0.0.0.0', port=5000)
    finally:
        stop_threads = True
        time.sleep(0.1)
        GPIO.cleanup()
        ser.close()
        print("🧹 Clean exit")
